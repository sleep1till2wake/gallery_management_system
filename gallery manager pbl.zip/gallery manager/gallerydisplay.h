#ifndef GALLERYDISPLAY_H
#define GALLERYDISPLAY_H

#include <string>
#include "gallery.cpp"
using namespace std;

class GalleryDisplay : public Gallery {
public:
    void displayGallery();
};

#endif
